
package com.example.employeeskillstracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeSkillsTrackerApplication {
    public static void main(String[] args) {
        SpringApplication.run(EmployeeSkillsTrackerApplication.class, args);
    }
}
